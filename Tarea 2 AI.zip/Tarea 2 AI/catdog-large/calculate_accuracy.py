# calculate_accuracy.py
import torch

def get_accuracy_per_class(model, data_loader, class_labels, is_pytorch=True):
    # Initialize counters
    correct_per_class = [0] * len(class_labels)
    total_per_class = [0] * len(class_labels)
    
    if is_pytorch:
        model.eval()

    if is_pytorch:
        # PyTorch forward pass
        with torch.no_grad():
            for images, labels in data_loader:
                outputs = model(images)
                _, predicted = torch.max(outputs, 1)
                for i in range(len(labels)):
                    label = int(labels[i])
                    pred = predicted[i].item()
                    total_per_class[label] += 1
                    if label == pred:
                        correct_per_class[label] += 1
    else:
        # TensorFlow/Keras forward pass, manual iteration over the generator
        steps = len(data_loader)  # Total number of steps (batches) in the validation set
        for i in range(steps):
            images, labels = next(data_loader)  # Get the next batch
            predicted = model.predict(images)  # Predict batch
            predicted = (predicted > 0.5).astype(int)  # Convert probabilities to binary class labels
            for j in range(len(labels)):
                label = int(labels[j])  # Cast label to an integer
                pred = int(predicted[j][0])  # Convert prediction to integer
                total_per_class[label] += 1
                if label == pred:
                    correct_per_class[label] += 1

    # Calculate accuracy per class
    accuracy_per_class = [correct / total if total > 0 else 0 for correct, total in zip(correct_per_class, total_per_class)]
    return accuracy_per_class
