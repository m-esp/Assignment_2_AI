import tensorflow as tf

class SimpleModel(tf.keras.Model):
    def __init__(self, number_of_classes):
        super(SimpleModel, self).__init__()        
        self.conv_1 = tf.keras.layers.Conv2D(16, (3,3), padding = 'same', kernel_initializer = 'he_normal', name = 'conv1')  
        self.max_pool = tf.keras.layers.MaxPool2D((3,3), strides = 2, padding = 'same')
        self.relu = tf.keras.layers.ReLU();        
        self.bn_conv_1 = tf.keras.layers.BatchNormalization()
        self.dropout_1 = tf.keras.layers.Dropout(0.5)

        self.conv_2 = tf.keras.layers.Conv2D(32, (3,3), padding = 'same', kernel_initializer='he_normal', name = 'conv2')  
        self.bn_conv_2 = tf.keras.layers.BatchNormalization()
        self.dropout_2 = tf.keras.layers.Dropout(0.5)

        self.conv_3 = tf.keras.layers.Conv2D(64, (3,3), padding = 'same', kernel_initializer='he_normal', name = 'conv3')  
        self.bn_conv_3 = tf.keras.layers.BatchNormalization()
        self.dropout_3 = tf.keras.layers.Dropout(0.5)

        self.fc1 = tf.keras.layers.Dense(128, kernel_initializer='he_normal', name = 'dense1')  
        self.bn_fc_1 = tf.keras.layers.BatchNormalization(name = 'embedding')
        self.fc2 = tf.keras.layers.Dense(1)

    def call(self, inputs):        
        x = self.conv_1(inputs)    
        x = self.bn_conv_1(x) 
        x = self.relu(x) 
        x = self.max_pool(x) 
        x = self.dropout_1(x)

        x = self.conv_2(x)  
        x = self.bn_conv_2(x) 
        x = self.relu(x) 
        x = self.max_pool(x)  
        x = self.dropout_2(x)

        x = self.conv_3(x)  
        x = self.bn_conv_3(x)
        x = self.relu(x)  
        x = self.max_pool(x)
        x = self.dropout_3(x)

        x = tf.keras.layers.Flatten()(x) 
        x = self.fc1(x)  
        x = self.bn_fc_1(x) 
        x = self.relu(x) 
        x = self.fc2(x) 
        x = tf.keras.activations.sigmoid(x)
        return x
