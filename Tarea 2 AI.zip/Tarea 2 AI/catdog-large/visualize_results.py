import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

def display_accuracy_table(cnn_accuracy_per_class, mlp_accuracy_per_class, class_labels):
    accuracy_df = pd.DataFrame({
        'Class': class_labels,
        'CNN Accuracy': cnn_accuracy_per_class,
        'MLP Accuracy': mlp_accuracy_per_class
    })
    
    # Display the accuracy table
    print(accuracy_df)
    return accuracy_df

def plot_accuracy_bar_chart(cnn_accuracy_per_class, mlp_accuracy_per_class, class_labels):
    bar_width = 0.35
    index = np.arange(len(class_labels))
    
    # Plot bars
    fig, ax = plt.subplots()
    bar1 = ax.bar(index, cnn_accuracy_per_class, bar_width, label='CNN')
    bar2 = ax.bar(index + bar_width, mlp_accuracy_per_class, bar_width, label='MLP')
    
    ax.set_xlabel('Class')
    ax.set_ylabel('Accuracy')
    ax.set_title('Accuracy per Class - CNN vs MLP')
    ax.set_xticks(index + bar_width / 2)
    ax.set_xticklabels(class_labels)
    ax.legend()
    
    plt.show()
