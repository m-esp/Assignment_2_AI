import torch
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
import os

# Function to check for data leakage
def check_data_leakage(train_dir, val_dir):
    train_files = set(os.listdir(train_dir))
    val_files = set(os.listdir(val_dir))

    # Check for overlap between training and validation datasets
    intersection = train_files.intersection(val_files)

    if intersection:
        print(f"Found {len(intersection)} overlapping images between training and validation sets!")
    else:
        print("No data leakage found between training and validation sets.")

# Function to get data loaders with improved augmentation for training
def get_data_loaders(train_dir, val_dir, batch_size=32):
    # Improved Data Augmentation for training
    train_transform = transforms.Compose([
        transforms.Resize((64, 64)),
        transforms.RandomHorizontalFlip(),
        transforms.RandomRotation(20),  # Increased random rotation
        transforms.RandomCrop(64, padding=4),
        transforms.ColorJitter(brightness=0.3, contrast=0.3, saturation=0.3, hue=0.1), 
        transforms.RandomResizedCrop(64, scale=(0.8, 1.0)),  # Added random zoom
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
    ])

    # Validation set: no augmentation, just resize and normalize
    val_transform = transforms.Compose([
        transforms.Resize((64, 64)),
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
    ])

    train_dataset = datasets.ImageFolder(root=train_dir, transform=train_transform)
    val_dataset = datasets.ImageFolder(root=val_dir, transform=val_transform)

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)

    return train_loader, val_loader

# Function to train and validate the model with early stopping
def train_model(model, train_loader, val_loader, epochs=10, lr=0.001, patience=3):
    import torch.optim as optim
    import torch.nn as nn

    optimizer = optim.SGD(model.parameters(), lr=lr, weight_decay=1e-4)  # Reduced learning rate with weight decay
    criterion = nn.CrossEntropyLoss()

    best_val_loss = float('inf')
    patience_counter = 0

    train_losses = []
    val_losses = []
    val_accuracies = []

    for epoch in range(epochs):
        model.train()
        train_loss = 0

        for images, labels in train_loader:
            outputs = model(images)
            loss = criterion(outputs, labels)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            train_loss += loss.item()

        avg_train_loss = train_loss / len(train_loader)
        train_losses.append(avg_train_loss)
        print(f"Epoch {epoch+1}/{epochs}, Training Loss: {avg_train_loss}")

        # Validation step
        model.eval()
        val_loss = 0
        correct = 0
        with torch.no_grad():
            for images, labels in val_loader:
                outputs = model(images)
                val_loss += criterion(outputs, labels).item()
                _, predicted = torch.max(outputs, 1)
                correct += (predicted == labels).sum().item()

        avg_val_loss = val_loss / len(val_loader)
        val_losses.append(avg_val_loss)
        val_accuracy = 100 * correct / len(val_loader.dataset)
        val_accuracies.append(val_accuracy)
        print(f"Validation Loss: {avg_val_loss}, Validation Accuracy: {val_accuracy} %")

        # Early stopping logic
        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            patience_counter = 0
        else:
            patience_counter += 1

        if patience_counter >= patience:
            print("Early stopping triggered")
            break

    # Return history for plotting
    return {'train_loss': train_losses, 'val_loss': val_losses, 'val_accuracy': val_accuracies}
