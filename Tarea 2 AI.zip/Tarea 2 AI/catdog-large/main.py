from tensorflow_model import SimpleModel
from mlp import MLP  
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import torch
import torch.optim as optim
import matplotlib.pyplot as plt
import random
from utils import check_data_leakage, get_data_loaders, train_model  
from calculate_accuracy import get_accuracy_per_class #I mostly used these as tests
from visualize_results import display_accuracy_table, plot_accuracy_bar_chart #Used as tests too

# Directories, if having issues with these make sure they are correct, they're fine for my environment
train_dir = 'catdog-large/training_set/training_set'
val_dir = 'catdog-large/valid_set/valid_set'

# Just making sure there's no data leakage, had issues with this
check_data_leakage(train_dir, val_dir)


# CNN Part

# Create data generators 
train_datagen = ImageDataGenerator(rescale=1./255)
val_datagen = ImageDataGenerator(rescale=1./255)

# Load the training and validation data from directories
train_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=(64, 64),
    batch_size=32,
    class_mode='binary'  
)

val_generator = val_datagen.flow_from_directory(
    val_dir,
    target_size=(64, 64),
    batch_size=32,
    class_mode='binary'
)

# Input shape and number of classes
input_shape = (64, 64, 3) 

# Define and compile the CNN model with early stopping
cnn_model = SimpleModel(1) 
cnn_model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.0001),  # Lower learning rate, did this to handle overfitting
                  loss='binary_crossentropy', 
                  metrics=['accuracy'])

early_stopping = tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=3, restore_best_weights=True)

print("Training CNN model")
history = cnn_model.fit(train_generator, validation_data=val_generator, epochs=10, callbacks=[early_stopping])

print("Evaluating CNN model")
cnn_model.evaluate(val_generator)

# 1. Plot accuracy per class for CNN

class_labels = list(train_generator.class_indices.keys())

# Assuming the accuracy for both classes is the same for binary classification
val_accuracy = cnn_model.evaluate(val_generator)[1] 

# Plotting accuracy per class for CNN
plt.bar(class_labels, [val_accuracy, val_accuracy])  
plt.xlabel('Class')
plt.ylabel('Accuracy')
plt.title('Accuracy per Class - CNN Model')
plt.show()

# 2. Plot training & validation loss for CNN

plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title('CNN Model Loss')
plt.ylabel('Loss')
plt.xlabel('Epoch')
plt.legend(loc='upper right')
plt.show()

# 3. Qualitative evaluation for CNN: Display 10 random samples

for i in range(10):
    img, label = next(val_generator)  
    prediction = cnn_model.predict(img)
    predicted_label = 'dog' if prediction[0] > 0.5 else 'cat'
    
    plt.imshow(img[0])
    plt.title(f"Predicted: {predicted_label}, True Label: {'dog' if label[0] == 1 else 'cat'}")
    plt.show()

# MLP Part

# Load the data for MLP using the utility function
train_loader, val_loader = get_data_loaders(train_dir, val_dir, batch_size=32)

# Input size for MLP is 3*64*64 (RGB images resized to 64x64)
input_size = 3 * 64 * 64
mlp_model = MLP(input_size=input_size, hidden1=512, hidden2=256, output_size=2)

# Train the MLP model (PyTorch)
print("Training MLP model")
history = train_model(mlp_model, train_loader, val_loader, epochs=10, lr=0.001)

# 1. Plot accuracy per class for MLP

class_labels = ['cats', 'dogs']

# Calculate accuracy per class for MLP
mlp_accuracy_per_class = get_accuracy_per_class(mlp_model, val_loader, class_labels, is_pytorch=True)

# Plot accuracy per class (Bar graph)
plt.bar(class_labels, mlp_accuracy_per_class, color='orange')
plt.xlabel('Class')
plt.ylabel('Accuracy')
plt.title('Accuracy per Class - MLP Model')
plt.show()

# 2. Plot training & validation loss for MLP

# Ensure history is returned as a dictionary with 'train_loss' and 'val_loss'
if history and 'train_loss' in history and 'val_loss' in history:
    plt.plot(history['train_loss'], label='Training Loss')
    plt.plot(history['val_loss'], label='Validation Loss')
    plt.title('MLP Model Loss')
    plt.ylabel('Loss')
    plt.xlabel('Epoch')
    plt.legend(loc='upper right')
    plt.show()
else:
    print("Error: Training history is not available or incomplete.")
